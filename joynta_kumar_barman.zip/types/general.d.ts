interface dropdown {
    id?: number,
    name?: string
}

interface name{
    id: number,
    name: string
}
