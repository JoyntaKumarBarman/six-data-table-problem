export const baseUrl = {
    url: process.env.NEXT_PUBLIC_DB_URL,
};
