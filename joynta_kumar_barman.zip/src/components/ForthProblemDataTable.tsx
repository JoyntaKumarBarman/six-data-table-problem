import React from 'react';

const ForthProblemDataTable = () => {
    return (
        <div>
            Forth ProblemDataTable
        </div>
    );
};

export default ForthProblemDataTable;