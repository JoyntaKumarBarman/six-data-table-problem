import React from 'react';

const SixthProblemDataTable = () => {
    return (
        <div>
            sixth ProblemDataTable
        </div>
    );
};

export default SixthProblemDataTable;