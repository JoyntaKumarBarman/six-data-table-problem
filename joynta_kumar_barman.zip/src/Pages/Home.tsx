import React from 'react';

const Home = () => {
    return (
        <div className="card">
            Start from here
        </div>
    );
};

export default Home;